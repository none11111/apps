import HomePage from './pages/HomePage';
import DailyReportPage from './pages/DailyReportPage';
import GitConfigPage from './pages/GitConfigPage';
import HistoryPage from './pages/HistoryPage';
import TrendsPage from './pages/TrendsPage';
import SettingsPage from './pages/SettingsPage';
import AdminPage from './pages/AdminPage';
import LoginPage from './pages/LoginPage';
import NotFound from './pages/NotFound';
import { MainLayout } from './components/layouts/MainLayout';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  children?: RouteConfig[];
}

const routes: RouteConfig[] = [
  {
    name: 'Login',
    path: '/login',
    element: <LoginPage />,
  },
  {
    name: 'Main',
    path: '/',
    element: <MainLayout />,
    children: [
      {
        name: 'Home',
        path: '/',
        element: <HomePage />,
      },
      {
        name: 'Daily Report',
        path: '/report',
        element: <DailyReportPage />,
      },
      {
        name: 'Git Config',
        path: '/git-config',
        element: <GitConfigPage />,
      },
      {
        name: 'History',
        path: '/history',
        element: <HistoryPage />,
      },
      {
        name: 'Trends',
        path: '/trends',
        element: <TrendsPage />,
      },
      {
        name: 'Settings',
        path: '/settings',
        element: <SettingsPage />,
      },
      {
        name: 'Admin',
        path: '/admin',
        element: <AdminPage />,
      },
    ],
  },
  {
    name: 'Not Found',
    path: '*',
    element: <NotFound />,
  },
];

export default routes;
