// 用户角色类型
export type UserRole = 'user' | 'admin';

// 用户配置类型
export interface Profile {
  id: string;
  username: string;
  email: string | null;
  role: UserRole;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

// Git 仓库配置类型
export interface GitRepository {
  id: string;
  user_id: string;
  name: string;
  url: string;
  branch: string;
  access_token: string | null;
  is_active: boolean;
  last_sync_at: string | null;
  created_at: string;
  updated_at: string;
}

// Git 提交记录类型
export interface GitCommit {
  hash: string;
  message: string;
  author: string;
  date: string;
  files_changed: number;
  insertions: number;
  deletions: number;
}

// 翻译内容类型
export interface TranslatedContent {
  what_done: string;
  why_important: string;
  blockers: string;
}

// 日报记录类型
export interface DailyReport {
  id: string;
  user_id: string;
  report_date: string;
  git_commits: GitCommit[];
  work_items?: string[];
  translated_content: TranslatedContent;
  what_done: string | null;
  why_important: string | null;
  blockers: string | null;
  voice_notes: string | null;
  activity_data: ActivityData | null;
  is_auto_generated: boolean;
  created_at: string;
  updated_at: string;
}

// 活跃度数据类型
export interface ActivityData {
  hourly: { hour: number; commits: number; lines: number }[];
  total_commits: number;
  total_lines: number;
  peak_hour: number;
}

// 工作趋势类型
export interface WorkTrend {
  id: string;
  user_id: string;
  date: string;
  commit_count: number;
  lines_added: number;
  lines_deleted: number;
  work_hours: number | null;
  activity_score: number | null;
  created_at: string;
}

// 阻塞预警类型
export interface Blocker {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'in_progress' | 'resolved';
  related_report_id: string | null;
  created_at: string;
  resolved_at: string | null;
  updated_at: string;
}

// 用户设置类型
export interface UserSettings {
  user_id: string;
  auto_pull_time: string;
  translation_style: 'professional' | 'casual' | 'technical' | 'humorous';
  language: 'zh-CN' | 'en-US' | 'ja-JP';
  notification_enabled: boolean;
  created_at: string;
  updated_at: string;
}

// 统计数据类型
export interface Statistics {
  total_reports: number;
  total_commits: number;
  total_lines: number;
  active_days: number;
  avg_commits_per_day: number;
  current_streak: number;
}
