import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getWorkTrends } from '@/db/api';
import type { WorkTrend } from '@/types';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, GitCommit, Code, Calendar } from 'lucide-react';
import { format } from 'date-fns';

export default function TrendsPage() {
  const { user } = useAuth();
  const [trends, setTrends] = useState<WorkTrend[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadTrends();
  }, [user]);

  const loadTrends = async () => {
    if (!user) return;

    try {
      const data = await getWorkTrends(user.id, 30);
      setTrends(data.reverse()); // 按时间正序排列
    } catch (error) {
      console.error('加载趋势数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const chartData = trends.map((trend) => ({
    date: format(new Date(trend.date), 'MM-dd'),
    commits: trend.commit_count,
    added: trend.lines_added,
    deleted: trend.lines_deleted,
    total: trend.lines_added + trend.lines_deleted,
  }));

  const totalCommits = trends.reduce((sum, t) => sum + t.commit_count, 0);
  const totalLinesAdded = trends.reduce((sum, t) => sum + t.lines_added, 0);
  const totalLinesDeleted = trends.reduce((sum, t) => sum + t.lines_deleted, 0);
  const avgCommitsPerDay = trends.length > 0 ? (totalCommits / trends.length).toFixed(1) : 0;

  if (loading) {
    return <div>加载中...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">工作趋势</h1>
        <p className="text-muted-foreground mt-2">
          查看您的工作数据和趋势分析
        </p>
      </div>

      {/* 统计卡片 */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">总提交数</CardTitle>
            <GitCommit className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalCommits}</div>
            <p className="text-xs text-muted-foreground mt-1">
              最近 30 天
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">日均提交</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgCommitsPerDay}</div>
            <p className="text-xs text-muted-foreground mt-1">
              平均每天
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">新增代码</CardTitle>
            <Code className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              +{(totalLinesAdded / 1000).toFixed(1)}K
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              代码行数
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">删除代码</CardTitle>
            <Code className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">
              -{(totalLinesDeleted / 1000).toFixed(1)}K
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              代码行数
            </p>
          </CardContent>
        </Card>
      </div>

      {/* 提交趋势图 */}
      <Card>
        <CardHeader>
          <CardTitle>提交趋势</CardTitle>
          <CardDescription>最近 30 天的提交数量变化</CardDescription>
        </CardHeader>
        <CardContent>
          {chartData.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Calendar className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>暂无趋势数据</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="commits"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  name="提交数"
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* 代码变更趋势 */}
      <Card>
        <CardHeader>
          <CardTitle>代码变更趋势</CardTitle>
          <CardDescription>最近 30 天的代码增删情况</CardDescription>
        </CardHeader>
        <CardContent>
          {chartData.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Code className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>暂无数据</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="added" fill="hsl(var(--success))" name="新增" />
                <Bar dataKey="deleted" fill="hsl(var(--destructive))" name="删除" />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* 活跃度日历 */}
      <Card>
        <CardHeader>
          <CardTitle>活跃度日历</CardTitle>
          <CardDescription>每日工作活跃度概览</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {chartData.slice(-28).map((day, index) => {
              const intensity = Math.min(day.commits / 10, 1);
              return (
                <div
                  key={index}
                  className="aspect-square rounded-md flex items-center justify-center text-xs font-medium transition-all hover:scale-110"
                  style={{
                    backgroundColor: `hsl(var(--primary) / ${intensity * 0.8 + 0.1})`,
                    color: intensity > 0.5 ? 'white' : 'hsl(var(--foreground))',
                  }}
                  title={`${day.date}: ${day.commits} 次提交`}
                >
                  {day.commits}
                </div>
              );
            })}
          </div>
          <div className="flex items-center justify-between mt-4 text-xs text-muted-foreground">
            <span>最近 28 天</span>
            <div className="flex items-center gap-2">
              <span>少</span>
              <div className="flex gap-1">
                {[0.2, 0.4, 0.6, 0.8, 1].map((opacity) => (
                  <div
                    key={opacity}
                    className="w-4 h-4 rounded-sm"
                    style={{ backgroundColor: `hsl(var(--primary) / ${opacity})` }}
                  />
                ))}
              </div>
              <span>多</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
