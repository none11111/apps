import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { getGitRepositories, createGitRepository, updateGitRepository, deleteGitRepository } from '@/db/api';
import type { GitRepository } from '@/types';
import { GitBranch, Plus, Trash2, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function GitConfigPage() {
  const { user } = useAuth();
  const [repositories, setRepositories] = useState<GitRepository[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRepo, setEditingRepo] = useState<GitRepository | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    url: '',
    branch: 'main',
    access_token: '',
    is_active: true,
  });

  useEffect(() => {
    if (!user) return;
    loadRepositories();
  }, [user]);

  const loadRepositories = async () => {
    if (!user) return;
    try {
      const data = await getGitRepositories(user.id);
      setRepositories(data);
    } catch (error) {
      console.error('加载仓库失败:', error);
      toast.error('加载仓库失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      if (editingRepo) {
        await updateGitRepository(editingRepo.id, formData);
        toast.success('更新成功');
      } else {
        await createGitRepository({
          ...formData,
          user_id: user.id,
        });
        toast.success('添加成功');
      }
      
      setDialogOpen(false);
      resetForm();
      loadRepositories();
    } catch (error) {
      console.error('保存失败:', error);
      toast.error('保存失败');
    }
  };

  const handleEdit = (repo: GitRepository) => {
    setEditingRepo(repo);
    setFormData({
      name: repo.name,
      url: repo.url,
      branch: repo.branch,
      access_token: repo.access_token || '',
      is_active: repo.is_active,
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('确定要删除这个仓库配置吗?')) return;

    try {
      await deleteGitRepository(id);
      toast.success('删除成功');
      loadRepositories();
    } catch (error) {
      console.error('删除失败:', error);
      toast.error('删除失败');
    }
  };

  const handleToggleActive = async (repo: GitRepository) => {
    try {
      await updateGitRepository(repo.id, { is_active: !repo.is_active });
      toast.success(repo.is_active ? '已禁用' : '已启用');
      loadRepositories();
    } catch (error) {
      console.error('更新失败:', error);
      toast.error('更新失败');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      url: '',
      branch: 'main',
      access_token: '',
      is_active: true,
    });
    setEditingRepo(null);
  };

  const handleDialogClose = (open: boolean) => {
    setDialogOpen(open);
    if (!open) {
      resetForm();
    }
  };

  if (loading) {
    return <div>加载中...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Git 仓库配置</h1>
          <p className="text-muted-foreground mt-2">
            配置您的 Git 仓库以自动拉取提交记录
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={handleDialogClose}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              添加仓库
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingRepo ? '编辑仓库' : '添加仓库'}</DialogTitle>
              <DialogDescription>
                配置 Git 仓库信息以自动拉取提交记录
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">仓库名称</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="例如: 主项目"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="url">仓库 URL</Label>
                <Input
                  id="url"
                  value={formData.url}
                  onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                  placeholder="https://github.com/username/repo.git"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="branch">分支名称</Label>
                <Input
                  id="branch"
                  value={formData.branch}
                  onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                  placeholder="main"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="token">访问令牌 (可选)</Label>
                <Input
                  id="token"
                  type="password"
                  value={formData.access_token}
                  onChange={(e) => setFormData({ ...formData, access_token: e.target.value })}
                  placeholder="用于私有仓库访问"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
                <Label htmlFor="active">启用此仓库</Label>
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={() => handleDialogClose(false)}>
                  取消
                </Button>
                <Button type="submit">
                  {editingRepo ? '更新' : '添加'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {repositories.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <GitBranch className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">暂无仓库配置</h3>
            <p className="text-muted-foreground text-center mb-4">
              添加您的第一个 Git 仓库开始自动生成日报
            </p>
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              添加仓库
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {repositories.map((repo) => (
            <Card key={repo.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="flex items-center gap-2">
                      {repo.name}
                      {!repo.is_active && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                          已禁用
                        </span>
                      )}
                    </CardTitle>
                    <CardDescription className="mt-1 break-all">
                      {repo.url}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">分支:</span>
                    <span className="font-mono">{repo.branch}</span>
                  </div>
                  {repo.last_sync_at && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">最后同步:</span>
                      <span>{format(new Date(repo.last_sync_at), 'yyyy-MM-dd HH:mm')}</span>
                    </div>
                  )}
                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => handleEdit(repo)}
                    >
                      编辑
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleToggleActive(repo)}
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(repo.id)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>使用说明</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>1. 添加您的 Git 仓库 URL 和分支信息</p>
          <p>2. 如果是私有仓库,需要提供访问令牌</p>
          <p>3. 系统将在每天 18:00 自动拉取当天的提交记录</p>
          <p>4. 您也可以在生成日报页面手动拉取最新提交</p>
        </CardContent>
      </Card>
    </div>
  );
}
