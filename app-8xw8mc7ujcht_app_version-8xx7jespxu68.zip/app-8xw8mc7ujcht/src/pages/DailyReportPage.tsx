import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getDailyReportByDate, createDailyReport, updateDailyReport } from '@/db/api';
import type { DailyReport } from '@/types';
import { Sparkles, Copy, Mic, RefreshCw, Save, Code2, Plus, X, Briefcase } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { supabase } from '@/db/supabase';
import { sendStreamRequest } from '@/utils/streamRequest';

interface WorkItem {
  id: string;
  content: string;
}

export default function DailyReportPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [translating, setTranslating] = useState(false);
  const [report, setReport] = useState<DailyReport | null>(null);
  const [whatDone, setWhatDone] = useState('');
  const [whyImportant, setWhyImportant] = useState('');
  const [blockers, setBlockers] = useState('');
  const [voiceNotes, setVoiceNotes] = useState('');
  const [gitCommits, setGitCommits] = useState('');
  const [workItems, setWorkItems] = useState<WorkItem[]>([{ id: '1', content: '' }]);
  const [inputMode, setInputMode] = useState<'git' | 'work'>('git');
  const abortControllerRef = useRef<AbortController | null>(null);

  const today = format(new Date(), 'yyyy-MM-dd');

  useEffect(() => {
    if (!user) return;
    loadTodayReport();
  }, [user]);

  const loadTodayReport = async () => {
    if (!user) return;
    
    try {
      const data = await getDailyReportByDate(user.id, today);
      if (data) {
        setReport(data);
        setWhatDone(data.what_done || '');
        setWhyImportant(data.why_important || '');
        setBlockers(data.blockers || '');
        setVoiceNotes(data.voice_notes || '');
        setGitCommits(JSON.stringify(data.git_commits, null, 2));
        
        // 加载工作内容
        if (data.work_items && Array.isArray(data.work_items) && data.work_items.length > 0) {
          setWorkItems(data.work_items.map((content: string, index: number) => ({
            id: String(index + 1),
            content,
          })));
        }
      }
    } catch (error) {
      console.error('加载日报失败:', error);
    }
  };

  // 工作内容管理函数
  const addWorkItem = () => {
    setWorkItems([...workItems, { id: String(Date.now()), content: '' }]);
  };

  const removeWorkItem = (id: string) => {
    if (workItems.length === 1) {
      toast.error('至少保留一个工作项');
      return;
    }
    setWorkItems(workItems.filter(item => item.id !== id));
  };

  const updateWorkItem = (id: string, content: string) => {
    setWorkItems(workItems.map(item => 
      item.id === id ? { ...item, content } : item
    ));
  };

  const handleAITranslate = async () => {
    let inputContent = '';
    
    if (inputMode === 'git') {
      if (!gitCommits.trim()) {
        toast.error('请先输入 Git 提交记录');
        return;
      }
      inputContent = gitCommits;
    } else {
      const workContent = workItems
        .filter(item => item.content.trim())
        .map(item => item.content)
        .join('\n');
      
      if (!workContent) {
        toast.error('请先输入工作内容');
        return;
      }
      inputContent = workContent;
    }

    setTranslating(true);
    abortControllerRef.current = new AbortController();

    let accumulatedContent = '';
    let currentSection = '';

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      await sendStreamRequest({
        functionUrl: `${supabaseUrl}/functions/v1/ai-translate`,
        requestBody: {
          commits: inputContent,
          mode: inputMode,
        },
        supabaseAnonKey,
        onData: (data) => {
          try {
            const parsed = JSON.parse(data);
            if (parsed.choices && parsed.choices[0]?.delta?.content) {
              const chunk = parsed.choices[0].delta.content;
              accumulatedContent += chunk;

              // 解析内容到对应的字段
              const sections = accumulatedContent.split('\n\n');
              sections.forEach((section) => {
                if (section.includes('今天做了什么:')) {
                  currentSection = 'what';
                  setWhatDone(section.replace('今天做了什么:', '').trim());
                } else if (section.includes('为什么重要:')) {
                  currentSection = 'why';
                  setWhyImportant(section.replace('为什么重要:', '').trim());
                } else if (section.includes('阻塞点:')) {
                  currentSection = 'blockers';
                  setBlockers(section.replace('阻塞点:', '').trim());
                } else if (currentSection === 'what') {
                  setWhatDone((prev) => prev + chunk);
                } else if (currentSection === 'why') {
                  setWhyImportant((prev) => prev + chunk);
                } else if (currentSection === 'blockers') {
                  setBlockers((prev) => prev + chunk);
                }
              });
            }
          } catch (e) {
            console.warn('解析失败:', e);
          }
        },
        onComplete: () => {
          setTranslating(false);
          toast.success('AI 翻译完成');
        },
        onError: (error) => {
          setTranslating(false);
          console.error('翻译失败:', error);
          toast.error('AI 翻译失败');
        },
        signal: abortControllerRef.current.signal,
      });
    } catch (error) {
      setTranslating(false);
      console.error('翻译失败:', error);
      toast.error('AI 翻译失败');
    }
  };

  const handleSave = async () => {
    if (!user) return;

    setLoading(true);
    try {
      let commits = [];
      try {
        commits = JSON.parse(gitCommits || '[]');
      } catch (e) {
        commits = [];
      }

      // 保存工作内容
      const workContent = workItems
        .filter(item => item.content.trim())
        .map(item => item.content);

      const reportData = {
        user_id: user.id,
        report_date: today,
        git_commits: commits,
        work_items: workContent,
        translated_content: {
          what_done: whatDone,
          why_important: whyImportant,
          blockers: blockers,
        },
        what_done: whatDone,
        why_important: whyImportant,
        blockers: blockers,
        voice_notes: voiceNotes,
        activity_data: null,
        is_auto_generated: false,
      };

      if (report) {
        await updateDailyReport(report.id, reportData);
        toast.success('更新成功');
      } else {
        const newReport = await createDailyReport(reportData);
        setReport(newReport);
        toast.success('保存成功');
      }
    } catch (error) {
      console.error('保存失败:', error);
      toast.error('保存失败');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    const content = `
📅 日期: ${format(new Date(), 'yyyy年MM月dd日')}

✅ 今天做了什么:
${whatDone}

💡 为什么重要:
${whyImportant}

⚠️ 阻塞点:
${blockers}

${voiceNotes ? `🎤 语音补充:\n${voiceNotes}` : ''}
    `.trim();

    navigator.clipboard.writeText(content);
    toast.success('已复制到剪贴板');
  };

  return (
    <div className="space-y-6">
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 rounded-2xl blur-3xl -z-10" />
        <div className="p-6 rounded-2xl bg-gradient-to-r from-primary/5 to-secondary/5 border-2">
          <h1 className="text-4xl font-bold gradient-text flex items-center gap-3">
            生成日报
            <Sparkles className="w-8 h-8 text-secondary animate-pulse" />
          </h1>
          <p className="text-muted-foreground mt-3 text-lg">
            使用 AI 智能翻译 Git 提交记录或工作内容,快速生成日报 ✨
          </p>
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        {/* 左侧: 输入区域 */}
        <Card className="border-2 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-primary/5 to-transparent">
            <CardTitle className="flex items-center gap-2">
              <Code2 className="w-5 h-5 text-primary" />
              输入工作内容
            </CardTitle>
            <CardDescription>
              选择输入方式：Git 提交记录或手动输入工作内容
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Tabs value={inputMode} onValueChange={(value) => setInputMode(value as 'git' | 'work')}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="git" className="flex items-center gap-2">
                  <Code2 className="w-4 h-4" />
                  Git 提交
                </TabsTrigger>
                <TabsTrigger value="work" className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4" />
                  工作内容
                </TabsTrigger>
              </TabsList>

              <TabsContent value="git" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="commits">提交记录 (JSON 格式)</Label>
                  <Textarea
                    id="commits"
                    value={gitCommits}
                    onChange={(e) => setGitCommits(e.target.value)}
                    placeholder='[{"message": "feat: 添加用户登录功能", "files_changed": 5}]'
                    className="min-h-[200px] font-mono text-sm"
                  />
                  <p className="text-xs text-muted-foreground">
                    💡 粘贴 Git 提交记录的 JSON 格式数据
                  </p>
                </div>
              </TabsContent>

              <TabsContent value="work" className="space-y-4 mt-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>今日工作内容</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addWorkItem}
                      className="h-8"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      添加
                    </Button>
                  </div>
                  
                  <div className="space-y-3">
                    {workItems.map((item, index) => (
                      <div key={item.id} className="flex gap-2 items-start">
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="text-xs">
                              {index + 1}
                            </Badge>
                          </div>
                          <Input
                            value={item.content}
                            onChange={(e) => updateWorkItem(item.id, e.target.value)}
                            placeholder="例如：完成用户登录模块的开发和测试"
                            className="w-full"
                          />
                        </div>
                        {workItems.length > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeWorkItem(item.id)}
                            className="h-10 w-10 p-0 text-destructive hover:text-destructive"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                  
                  <p className="text-xs text-muted-foreground">
                    💡 输入今天完成的工作内容，AI 会自动生成对应的日报
                  </p>
                </div>
              </TabsContent>
            </Tabs>

            <Button
              onClick={handleAITranslate}
              disabled={translating}
              className="w-full shine-effect shadow-lg"
              size="lg"
            >
              {translating ? (
                <>
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                  AI 翻译中...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  AI 智能翻译
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* 右侧: 翻译结果 */}
        <Card className="border-2 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-secondary/5 to-transparent">
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-secondary" />
              日报内容
            </CardTitle>
            <CardDescription>
              AI 翻译结果,可手动编辑调整
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="what-done">✅ 今天做了什么</Label>
              <Textarea
                id="what-done"
                value={whatDone}
                onChange={(e) => setWhatDone(e.target.value)}
                placeholder="描述今天完成的主要工作..."
                className="min-h-[100px]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="why-important">💡 为什么重要</Label>
              <Textarea
                id="why-important"
                value={whyImportant}
                onChange={(e) => setWhyImportant(e.target.value)}
                placeholder="说明工作的价值和意义..."
                className="min-h-[80px]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="blockers">⚠️ 阻塞点</Label>
              <Textarea
                id="blockers"
                value={blockers}
                onChange={(e) => setBlockers(e.target.value)}
                placeholder="遇到的问题和需要协助的地方..."
                className="min-h-[80px]"
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 语音补充 */}
      <Card className="border-2 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-accent/5 to-transparent">
          <CardTitle className="flex items-center gap-2">
            <Mic className="w-5 h-5 text-accent" />
            语音补充 (可选)
          </CardTitle>
          <CardDescription>
            补充说明或额外信息
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            value={voiceNotes}
            onChange={(e) => setVoiceNotes(e.target.value)}
            placeholder="输入补充说明..."
            className="min-h-[100px]"
          />
        </CardContent>
      </Card>

      {/* 操作按钮 */}
      <div className="flex gap-4 flex-wrap">
        <Button onClick={handleSave} disabled={loading} size="lg" className="shine-effect shadow-lg hover:shadow-xl">
          <Save className="w-5 h-5 mr-2" />
          {loading ? '保存中...' : '保存日报'}
        </Button>
        <Button onClick={handleCopy} variant="outline" size="lg" className="card-hover border-2">
          <Copy className="w-5 h-5 mr-2" />
          复制内容
        </Button>
      </div>

      {/* 提示信息 */}
      <Card className="bg-gradient-to-r from-primary/5 to-secondary/5 border-2 border-primary/20 shadow-lg">
        <CardContent className="pt-6">
          <div className="flex gap-3 items-start">
            <div className="p-2 rounded-lg bg-primary/10">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <div className="font-semibold mb-1 flex items-center gap-2">
                💡 使用提示
              </div>
              <p className="text-sm text-muted-foreground">
                您可以直接编辑 AI 翻译的内容,或完全手动输入日报内容。AI 会根据您的 Git 提交记录智能生成专业的日报描述。
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
