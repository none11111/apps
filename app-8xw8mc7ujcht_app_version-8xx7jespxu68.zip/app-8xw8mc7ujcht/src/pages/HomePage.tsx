import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { getStatistics, getDailyReports, getBlockers } from '@/db/api';
import type { Statistics, DailyReport, Blocker } from '@/types';
import { FileText, GitCommit, Code, TrendingUp, AlertTriangle, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';

export default function HomePage() {
  const { user } = useAuth();
  const [statistics, setStatistics] = useState<Statistics | null>(null);
  const [recentReports, setRecentReports] = useState<DailyReport[]>([]);
  const [activeBlockers, setActiveBlockers] = useState<Blocker[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const loadData = async () => {
      try {
        const [stats, reports, blockers] = await Promise.all([
          getStatistics(user.id),
          getDailyReports(user.id, 5),
          getBlockers(user.id, 'open'),
        ]);

        setStatistics(stats);
        setRecentReports(reports);
        setActiveBlockers(blockers);
      } catch (error) {
        console.error('加载数据失败:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [user]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-24 bg-muted" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 bg-muted" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">仪表盘</h1>
          <p className="text-muted-foreground mt-2 text-lg">
            欢迎回来,查看您的工作概览 👋
          </p>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Card className="card-hover border-2 shine-effect overflow-hidden relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-full -mr-12 -mt-12" />
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">总日报数</CardTitle>
            <div className="p-2 rounded-lg bg-primary/10">
              <FileText className="h-5 w-5 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{statistics?.total_reports || 0}</div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              累计生成日报
            </p>
          </CardContent>
        </Card>

        <Card className="card-hover border-2 shine-effect overflow-hidden relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-secondary/5 rounded-full -mr-12 -mt-12" />
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">总提交数</CardTitle>
            <div className="p-2 rounded-lg bg-secondary/10">
              <GitCommit className="h-5 w-5 text-secondary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-secondary">{statistics?.total_commits || 0}</div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              Git 提交记录
            </p>
          </CardContent>
        </Card>

        <Card className="card-hover border-2 shine-effect overflow-hidden relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-accent/5 rounded-full -mr-12 -mt-12" />
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">代码行数</CardTitle>
            <div className="p-2 rounded-lg bg-accent/10">
              <Code className="h-5 w-5 text-accent" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-accent">
              {statistics?.total_lines ? (statistics.total_lines / 1000).toFixed(1) + 'K' : 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              增删代码总量
            </p>
          </CardContent>
        </Card>

        <Card className="card-hover border-2 shine-effect overflow-hidden relative bg-gradient-to-br from-primary/5 to-secondary/5">
          <div className="absolute top-0 right-0 w-24 h-24 bg-success/5 rounded-full -mr-12 -mt-12" />
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">连续天数</CardTitle>
            <div className="p-2 rounded-lg bg-success/10">
              <TrendingUp className="h-5 w-5 text-success" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-success">{statistics?.current_streak || 0}</div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              🔥 连续工作天数
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        {/* 最近日报 */}
        <Card className="border-2 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-primary/5 to-transparent">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-primary" />
                  最近日报
                </CardTitle>
                <CardDescription>最近 5 条日报记录</CardDescription>
              </div>
              <Button asChild variant="outline" size="sm" className="shine-effect">
                <Link to="/history">查看全部</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {recentReports.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Calendar className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>暂无日报记录</p>
                <Button asChild className="mt-4" size="sm">
                  <Link to="/report">生成第一份日报</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {recentReports.map((report) => (
                  <div
                    key={report.id}
                    className="flex items-start gap-4 p-4 rounded-lg border border-border hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium">
                          {format(new Date(report.report_date), 'yyyy年MM月dd日', { locale: zhCN })}
                        </span>
                        {report.is_auto_generated && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                            自动生成
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {report.what_done || '暂无内容'}
                      </p>
                    </div>
                    <Button asChild variant="ghost" size="sm">
                      <Link to={`/history?date=${report.report_date}`}>查看</Link>
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* 活跃阻塞 */}
        <Card className="border-2 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-warning/5 to-transparent">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-warning" />
                  活跃阻塞
                </CardTitle>
                <CardDescription>需要关注的阻塞问题</CardDescription>
              </div>
              <Button asChild variant="outline" size="sm" className="shine-effect">
                <Link to="/report">管理阻塞</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {activeBlockers.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <AlertTriangle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>暂无活跃阻塞</p>
                <p className="text-sm mt-1">工作进展顺利 🎉</p>
              </div>
            ) : (
              <div className="space-y-4">
                {activeBlockers.map((blocker) => (
                  <div
                    key={blocker.id}
                    className="flex items-start gap-4 p-4 rounded-lg border border-border"
                  >
                    <div
                      className={`w-2 h-2 rounded-full mt-2 ${
                        blocker.severity === 'critical'
                          ? 'bg-destructive'
                          : blocker.severity === 'high'
                          ? 'bg-warning'
                          : 'bg-info'
                      }`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="font-medium mb-1">{blocker.title}</div>
                      {blocker.description && (
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {blocker.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                        <span className="capitalize">{blocker.severity}</span>
                        <span>•</span>
                        <span>{format(new Date(blocker.created_at), 'MM-dd HH:mm')}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* 快速操作 */}
      <Card className="border-2 shadow-lg bg-gradient-to-br from-background to-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            ⚡ 快速操作
          </CardTitle>
          <CardDescription>常用功能快捷入口</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <Button asChild className="h-auto py-8 flex-col gap-3 text-base shine-effect shadow-lg hover:shadow-xl">
              <Link to="/report">
                <div className="p-3 rounded-full bg-primary-foreground/20">
                  <FileText className="w-7 h-7" />
                </div>
                <span className="font-semibold">生成今日日报</span>
              </Link>
            </Button>
            <Button asChild variant="outline" className="h-auto py-8 flex-col gap-3 text-base card-hover border-2">
              <Link to="/git-config">
                <div className="p-3 rounded-full bg-secondary/10">
                  <GitCommit className="w-7 h-7 text-secondary" />
                </div>
                <span className="font-semibold">配置 Git 仓库</span>
              </Link>
            </Button>
            <Button asChild variant="outline" className="h-auto py-8 flex-col gap-3 text-base card-hover border-2">
              <Link to="/trends">
                <div className="p-3 rounded-full bg-accent/10">
                  <TrendingUp className="w-7 h-7 text-accent" />
                </div>
                <span className="font-semibold">查看工作趋势</span>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
