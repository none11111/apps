import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { getUserSettings, updateUserSettings } from '@/db/api';
import type { UserSettings } from '@/types';
import { Settings as SettingsIcon, Save } from 'lucide-react';
import { toast } from 'sonner';

export default function SettingsPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<UserSettings | null>(null);

  const [formData, setFormData] = useState({
    auto_pull_time: '18:00:00',
    translation_style: 'professional' as 'professional' | 'casual' | 'technical' | 'humorous',
    language: 'zh-CN' as 'zh-CN' | 'en-US' | 'ja-JP',
    notification_enabled: true,
  });

  useEffect(() => {
    if (!user) return;
    loadSettings();
  }, [user]);

  const loadSettings = async () => {
    if (!user) return;

    try {
      const data = await getUserSettings(user.id);
      if (data) {
        setSettings(data);
        setFormData({
          auto_pull_time: data.auto_pull_time,
          translation_style: data.translation_style as any,
          language: data.language as any,
          notification_enabled: data.notification_enabled,
        });
      }
    } catch (error) {
      console.error('加载设置失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user) return;

    setSaving(true);
    try {
      await updateUserSettings(user.id, formData);
      toast.success('设置已保存');
      loadSettings();
    } catch (error) {
      console.error('保存设置失败:', error);
      toast.error('保存设置失败');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div>加载中...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <SettingsIcon className="w-8 h-8" />
          个人设置
        </h1>
        <p className="text-muted-foreground mt-2">
          配置您的个性化偏好
        </p>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        {/* 基本设置 */}
        <Card>
          <CardHeader>
            <CardTitle>基本设置</CardTitle>
            <CardDescription>配置日报生成的基本参数</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="auto-pull-time">自动拉取时间</Label>
              <Input
                id="auto-pull-time"
                type="time"
                value={formData.auto_pull_time.substring(0, 5)}
                onChange={(e) =>
                  setFormData({ ...formData, auto_pull_time: e.target.value + ':00' })
                }
              />
              <p className="text-xs text-muted-foreground">
                系统将在此时间自动拉取 Git 提交记录
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="translation-style">翻译风格</Label>
              <Select
                value={formData.translation_style}
                onValueChange={(value: any) =>
                  setFormData({ ...formData, translation_style: value })
                }
              >
                <SelectTrigger id="translation-style">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">专业正式</SelectItem>
                  <SelectItem value="casual">轻松随意</SelectItem>
                  <SelectItem value="technical">技术详细</SelectItem>
                  <SelectItem value="humorous">幽默风趣</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                AI 翻译时使用的语言风格
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="language">界面语言</Label>
              <Select
                value={formData.language}
                onValueChange={(value: any) =>
                  setFormData({ ...formData, language: value })
                }
              >
                <SelectTrigger id="language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="zh-CN">简体中文</SelectItem>
                  <SelectItem value="en-US">English</SelectItem>
                  <SelectItem value="ja-JP">日本語</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                应用界面显示语言
              </p>
            </div>
          </CardContent>
        </Card>

        {/* 通知设置 */}
        <Card>
          <CardHeader>
            <CardTitle>通知设置</CardTitle>
            <CardDescription>管理通知和提醒</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="notification">启用通知</Label>
                <p className="text-xs text-muted-foreground">
                  接收日报生成和阻塞预警通知
                </p>
              </div>
              <Switch
                id="notification"
                checked={formData.notification_enabled}
                onCheckedChange={(checked) =>
                  setFormData({ ...formData, notification_enabled: checked })
                }
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 保存按钮 */}
      <div className="flex gap-4">
        <Button onClick={handleSave} disabled={saving} size="lg">
          <Save className="w-4 h-4 mr-2" />
          {saving ? '保存中...' : '保存设置'}
        </Button>
      </div>

      {/* 使用提示 */}
      <Card className="bg-primary/5 border-primary/20">
        <CardHeader>
          <CardTitle className="text-base">使用提示</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• 自动拉取功能需要先配置 Git 仓库</p>
          <p>• 翻译风格会影响 AI 生成的日报语言风格</p>
          <p>• 通知功能需要浏览器支持并授权</p>
        </CardContent>
      </Card>
    </div>
  );
}
