import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { getDailyReports } from '@/db/api';
import type { DailyReport } from '@/types';
import { Calendar, Search, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';

export default function HistoryPage() {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const [reports, setReports] = useState<DailyReport[]>([]);
  const [filteredReports, setFilteredReports] = useState<DailyReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedReport, setSelectedReport] = useState<DailyReport | null>(null);

  useEffect(() => {
    if (!user) return;
    loadReports();
  }, [user]);

  useEffect(() => {
    const dateParam = searchParams.get('date');
    if (dateParam && reports.length > 0) {
      const report = reports.find((r) => r.report_date === dateParam);
      if (report) {
        setSelectedReport(report);
      }
    }
  }, [searchParams, reports]);

  useEffect(() => {
    if (searchQuery.trim()) {
      const filtered = reports.filter(
        (report) =>
          report.what_done?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          report.why_important?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          report.blockers?.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredReports(filtered);
    } else {
      setFilteredReports(reports);
    }
  }, [searchQuery, reports]);

  const loadReports = async () => {
    if (!user) return;

    try {
      const data = await getDailyReports(user.id, 100);
      setReports(data);
      setFilteredReports(data);
      if (data.length > 0 && !selectedReport) {
        setSelectedReport(data[0]);
      }
    } catch (error) {
      console.error('加载历史记录失败:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>加载中...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">历史记录</h1>
        <p className="text-muted-foreground mt-2">
          查看和管理您的历史日报
        </p>
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        {/* 左侧: 日报列表 */}
        <Card className="xl:col-span-1">
          <CardHeader>
            <CardTitle>日报列表</CardTitle>
            <CardDescription>共 {reports.length} 条记录</CardDescription>
            <div className="relative mt-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="搜索日报内容..."
                className="pl-9"
              />
            </div>
          </CardHeader>
          <CardContent>
            {filteredReports.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>暂无日报记录</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {filteredReports.map((report) => (
                  <button
                    key={report.id}
                    onClick={() => setSelectedReport(report)}
                    className={`w-full text-left p-4 rounded-lg border transition-colors ${
                      selectedReport?.id === report.id
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:bg-accent/50'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="font-medium">
                        {format(new Date(report.report_date), 'yyyy年MM月dd日', { locale: zhCN })}
                      </span>
                    </div>
                    {report.is_auto_generated && (
                      <Badge variant="secondary" className="text-xs mb-2">
                        自动生成
                      </Badge>
                    )}
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {report.what_done || '暂无内容'}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* 右侧: 日报详情 */}
        <Card className="xl:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>
                  {selectedReport
                    ? format(new Date(selectedReport.report_date), 'yyyy年MM月dd日', { locale: zhCN })
                    : '选择日报查看详情'}
                </CardTitle>
                {selectedReport && (
                  <CardDescription>
                    创建于 {format(new Date(selectedReport.created_at), 'yyyy-MM-dd HH:mm')}
                  </CardDescription>
                )}
              </div>
              {selectedReport && (
                <div className="flex gap-2">
                  {selectedReport.is_auto_generated && (
                    <Badge variant="secondary">自动生成</Badge>
                  )}
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {!selectedReport ? (
              <div className="text-center py-12 text-muted-foreground">
                <FileText className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p>请从左侧选择一条日报查看详情</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* 今天做了什么 */}
                <div>
                  <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                    ✅ 今天做了什么
                  </h3>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="whitespace-pre-wrap">
                      {selectedReport.what_done || '暂无内容'}
                    </p>
                  </div>
                </div>

                {/* 为什么重要 */}
                <div>
                  <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                    💡 为什么重要
                  </h3>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="whitespace-pre-wrap">
                      {selectedReport.why_important || '暂无内容'}
                    </p>
                  </div>
                </div>

                {/* 阻塞点 */}
                <div>
                  <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                    ⚠️ 阻塞点
                  </h3>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="whitespace-pre-wrap">
                      {selectedReport.blockers || '无阻塞'}
                    </p>
                  </div>
                </div>

                {/* 语音补充 */}
                {selectedReport.voice_notes && (
                  <div>
                    <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      🎤 语音补充
                    </h3>
                    <div className="p-4 rounded-lg bg-muted/50">
                      <p className="whitespace-pre-wrap">
                        {selectedReport.voice_notes}
                      </p>
                    </div>
                  </div>
                )}

                {/* Git 提交记录 */}
                {selectedReport.git_commits && selectedReport.git_commits.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      📝 Git 提交记录
                    </h3>
                    <div className="p-4 rounded-lg bg-muted/50 space-y-2">
                      {selectedReport.git_commits.map((commit: any, index: number) => (
                        <div key={index} className="text-sm">
                          <span className="font-mono text-xs text-muted-foreground">
                            {commit.hash?.substring(0, 7)}
                          </span>
                          <span className="ml-2">{commit.message}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 操作按钮 */}
                <div className="flex gap-2 pt-4">
                  <Button
                    onClick={() => {
                      const content = `
📅 日期: ${format(new Date(selectedReport.report_date), 'yyyy年MM月dd日', { locale: zhCN })}

✅ 今天做了什么:
${selectedReport.what_done || '暂无内容'}

💡 为什么重要:
${selectedReport.why_important || '暂无内容'}

⚠️ 阻塞点:
${selectedReport.blockers || '无阻塞'}

${selectedReport.voice_notes ? `🎤 语音补充:\n${selectedReport.voice_notes}` : ''}
                      `.trim();
                      navigator.clipboard.writeText(content);
                    }}
                  >
                    复制内容
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
