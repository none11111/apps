import { Link, useLocation } from 'react-router-dom';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from '@/components/ui/sidebar';
import { useAuth } from '@/contexts/AuthContext';
import {
  Home,
  FileText,
  GitBranch,
  TrendingUp,
  Settings,
  Shield,
  History,
  Code2,
  Sparkles,
} from 'lucide-react';

const menuItems = [
  { title: '仪表盘', icon: Home, url: '/' },
  { title: '生成日报', icon: FileText, url: '/report' },
  { title: 'Git 配置', icon: GitBranch, url: '/git-config' },
  { title: '历史记录', icon: History, url: '/history' },
  { title: '工作趋势', icon: TrendingUp, url: '/trends' },
  { title: '设置', icon: Settings, url: '/settings' },
];

const adminItems = [
  { title: '管理后台', icon: Shield, url: '/admin' },
];

export function AppSidebar() {
  const location = useLocation();
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin';

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border p-4 bg-gradient-to-br from-primary/5 to-secondary/5">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-secondary/20 shadow-lg group-hover:shadow-xl transition-all group-hover:scale-105">
            <Code2 className="w-7 h-7 text-primary" />
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-xl gradient-text flex items-center gap-1">
              智译日报
              <Sparkles className="w-4 h-4 text-secondary animate-pulse" />
            </span>
            <span className="text-xs text-muted-foreground font-medium">AI 日报助手</span>
          </div>
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>主要功能</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton
                    asChild
                    isActive={location.pathname === item.url}
                  >
                    <Link to={item.url}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>管理功能</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {adminItems.map((item) => (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton
                      asChild
                      isActive={location.pathname === item.url}
                    >
                      <Link to={item.url}>
                        <item.icon className="w-4 h-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border p-4 bg-gradient-to-br from-primary/5 to-transparent">
        <div className="text-xs text-muted-foreground flex items-center gap-2">
          <Sparkles className="w-3 h-3 text-primary" />
          <span>© 2026 智译日报</span>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
