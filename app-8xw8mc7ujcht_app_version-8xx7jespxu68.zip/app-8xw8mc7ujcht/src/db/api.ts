import { supabase } from './supabase';
import type {
  Profile,
  GitRepository,
  DailyReport,
  WorkTrend,
  Blocker,
  UserSettings,
  Statistics,
} from '@/types';

// ==================== 用户相关 ====================

export const getProfile = async (userId: string): Promise<Profile | null> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const updateProfile = async (
  userId: string,
  updates: Partial<Profile>
): Promise<Profile> => {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const getAllProfiles = async (): Promise<Profile[]> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

// ==================== Git 仓库相关 ====================

export const getGitRepositories = async (userId: string): Promise<GitRepository[]> => {
  const { data, error } = await supabase
    .from('git_repositories')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createGitRepository = async (
  repository: Omit<GitRepository, 'id' | 'created_at' | 'updated_at' | 'last_sync_at'>
): Promise<GitRepository> => {
  const { data, error } = await supabase
    .from('git_repositories')
    .insert(repository)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateGitRepository = async (
  id: string,
  updates: Partial<GitRepository>
): Promise<GitRepository> => {
  const { data, error } = await supabase
    .from('git_repositories')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const deleteGitRepository = async (id: string): Promise<void> => {
  const { error } = await supabase.from('git_repositories').delete().eq('id', id);

  if (error) throw error;
};

// ==================== 日报相关 ====================

export const getDailyReports = async (
  userId: string,
  limit = 30
): Promise<DailyReport[]> => {
  const { data, error } = await supabase
    .from('daily_reports')
    .select('*')
    .eq('user_id', userId)
    .order('report_date', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getDailyReportByDate = async (
  userId: string,
  date: string
): Promise<DailyReport | null> => {
  const { data, error } = await supabase
    .from('daily_reports')
    .select('*')
    .eq('user_id', userId)
    .eq('report_date', date)
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const createDailyReport = async (
  report: Omit<DailyReport, 'id' | 'created_at' | 'updated_at'>
): Promise<DailyReport> => {
  const { data, error } = await supabase
    .from('daily_reports')
    .insert(report)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateDailyReport = async (
  id: string,
  updates: Partial<DailyReport>
): Promise<DailyReport> => {
  const { data, error } = await supabase
    .from('daily_reports')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const deleteDailyReport = async (id: string): Promise<void> => {
  const { error } = await supabase.from('daily_reports').delete().eq('id', id);

  if (error) throw error;
};

// ==================== 工作趋势相关 ====================

export const getWorkTrends = async (
  userId: string,
  days = 30
): Promise<WorkTrend[]> => {
  const { data, error } = await supabase
    .from('work_trends')
    .select('*')
    .eq('user_id', userId)
    .order('date', { ascending: false })
    .limit(days);

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createWorkTrend = async (
  trend: Omit<WorkTrend, 'id' | 'created_at'>
): Promise<WorkTrend> => {
  const { data, error } = await supabase
    .from('work_trends')
    .insert(trend)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateWorkTrend = async (
  id: string,
  updates: Partial<WorkTrend>
): Promise<WorkTrend> => {
  const { data, error } = await supabase
    .from('work_trends')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
};

// ==================== 阻塞预警相关 ====================

export const getBlockers = async (
  userId: string,
  status?: string
): Promise<Blocker[]> => {
  let query = supabase
    .from('blockers')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (status) {
    query = query.eq('status', status);
  }

  const { data, error } = await query;

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createBlocker = async (
  blocker: Omit<Blocker, 'id' | 'created_at' | 'updated_at' | 'resolved_at'>
): Promise<Blocker> => {
  const { data, error } = await supabase
    .from('blockers')
    .insert(blocker)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateBlocker = async (
  id: string,
  updates: Partial<Blocker>
): Promise<Blocker> => {
  const { data, error } = await supabase
    .from('blockers')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const deleteBlocker = async (id: string): Promise<void> => {
  const { error } = await supabase.from('blockers').delete().eq('id', id);

  if (error) throw error;
};

// ==================== 用户设置相关 ====================

export const getUserSettings = async (userId: string): Promise<UserSettings | null> => {
  const { data, error } = await supabase
    .from('user_settings')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const updateUserSettings = async (
  userId: string,
  updates: Partial<UserSettings>
): Promise<UserSettings> => {
  const { data, error } = await supabase
    .from('user_settings')
    .update(updates)
    .eq('user_id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
};

// ==================== 统计数据相关 ====================

export const getStatistics = async (userId: string): Promise<Statistics> => {
  // 获取总日报数
  const { count: totalReports } = await supabase
    .from('daily_reports')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId);

  // 获取工作趋势数据
  const { data: trends } = await supabase
    .from('work_trends')
    .select('*')
    .eq('user_id', userId)
    .order('date', { ascending: false });

  const trendsArray = Array.isArray(trends) ? trends : [];
  const totalCommits = trendsArray.reduce((sum, t) => sum + t.commit_count, 0);
  const totalLines = trendsArray.reduce(
    (sum, t) => sum + t.lines_added + t.lines_deleted,
    0
  );
  const activeDays = trendsArray.length;

  // 计算连续天数
  let currentStreak = 0;
  const today = new Date();
  for (let i = 0; i < trendsArray.length; i++) {
    const trendDate = new Date(trendsArray[i].date);
    const diffDays = Math.floor(
      (today.getTime() - trendDate.getTime()) / (1000 * 60 * 60 * 24)
    );
    if (diffDays === i) {
      currentStreak++;
    } else {
      break;
    }
  }

  return {
    total_reports: totalReports || 0,
    total_commits: totalCommits,
    total_lines: totalLines,
    active_days: activeDays,
    avg_commits_per_day: activeDays > 0 ? totalCommits / activeDays : 0,
    current_streak: currentStreak,
  };
};
