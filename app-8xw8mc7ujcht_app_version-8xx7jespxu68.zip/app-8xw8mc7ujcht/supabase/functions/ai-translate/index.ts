const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { commits, mode = 'git' } = await req.json();

    if (!commits) {
      return new Response(
        JSON.stringify({ error: 'Missing commits parameter' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // 获取 API 密钥
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'API key not configured' }),
        {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // 根据模式构建不同的提示词
    let prompt = '';
    
    if (mode === 'work') {
      prompt = `你是一个专业的日报助手,请将以下工作内容转换成规范的日报格式。

工作内容:
${commits}

请按照以下格式输出:

今天做了什么:
[用 2-3 句话总结今天完成的主要工作,使用非技术人员能理解的语言]

为什么重要:
[说明这些工作的价值和意义,对项目或业务的影响]

阻塞点:
[如果有遇到的问题或需要协助的地方,请说明;如果没有,写"无阻塞"]

要求:
1. 使用简洁、专业的语言
2. 避免技术术语,用业务语言描述
3. 突出工作的价值和成果
4. 如实反映问题和困难`;
    } else {
      prompt = `你是一个专业的日报助手,请将以下 Git 提交记录翻译成易懂的日报内容。

Git 提交记录:
${commits}

请按照以下格式输出:

今天做了什么:
[用 2-3 句话总结今天完成的主要工作,使用非技术人员能理解的语言]

为什么重要:
[说明这些工作的价值和意义,对项目或业务的影响]

阻塞点:
[如果有遇到的问题或需要协助的地方,请说明;如果没有,写"无阻塞"]

要求:
1. 使用简洁、专业的语言
2. 避免技术术语,用业务语言描述
3. 突出工作的价值和成果
4. 如实反映问题和困难`;
    }

    // 调用文心大模型 API
    const response = await fetch(
      'https://app-8xw8mc7ujcht-api-zYkZz8qovQ1L-gateway.appmiaoda.com/v2/chat/completions',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          messages: [
            {
              role: 'system',
              content: '你是一个专业的日报助手,擅长将技术语言转换成易懂的业务语言。',
            },
            {
              role: 'user',
              content: prompt,
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API Error:', errorText);
      return new Response(
        JSON.stringify({ error: 'AI translation failed', details: errorText }),
        {
          status: response.status,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // 设置 SSE 响应头
    const headers = {
      ...corsHeaders,
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    };

    // 创建流式响应
    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader();
        if (!reader) {
          controller.close();
          return;
        }

        const decoder = new TextDecoder();
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value, { stream: true });
            const lines = chunk.split('\n').filter((line) => line.trim());

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6);
                if (data === '[DONE]') continue;

                try {
                  const parsed = JSON.parse(data);
                  // 转发数据
                  controller.enqueue(
                    new TextEncoder().encode(`data: ${JSON.stringify(parsed)}\n\n`)
                  );
                } catch (e) {
                  console.error('Parse error:', e);
                }
              }
            }
          }
        } catch (error) {
          console.error('Stream error:', error);
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, { headers });
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
