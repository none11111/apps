-- 创建用户角色枚举
CREATE TYPE public.user_role AS ENUM ('user', 'admin');

-- 创建用户配置表
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  email text,
  role public.user_role NOT NULL DEFAULT 'user',
  avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 创建 Git 仓库配置表
CREATE TABLE public.git_repositories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  url text NOT NULL,
  branch text DEFAULT 'main',
  access_token text,
  is_active boolean NOT NULL DEFAULT true,
  last_sync_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 创建日报记录表
CREATE TABLE public.daily_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  report_date date NOT NULL,
  git_commits jsonb NOT NULL DEFAULT '[]',
  translated_content jsonb NOT NULL DEFAULT '{}',
  what_done text,
  why_important text,
  blockers text,
  voice_notes text,
  activity_data jsonb,
  is_auto_generated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, report_date)
);

-- 创建工作趋势表
CREATE TABLE public.work_trends (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  date date NOT NULL,
  commit_count integer NOT NULL DEFAULT 0,
  lines_added integer NOT NULL DEFAULT 0,
  lines_deleted integer NOT NULL DEFAULT 0,
  work_hours decimal(5,2),
  activity_score integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, date)
);

-- 创建阻塞预警表
CREATE TABLE public.blockers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  severity text NOT NULL DEFAULT 'medium',
  status text NOT NULL DEFAULT 'open',
  related_report_id uuid REFERENCES public.daily_reports(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 创建用户设置表
CREATE TABLE public.user_settings (
  user_id uuid PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  auto_pull_time time DEFAULT '18:00:00',
  translation_style text DEFAULT 'professional',
  language text DEFAULT 'zh-CN',
  notification_enabled boolean DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 创建索引
CREATE INDEX idx_git_repositories_user_id ON public.git_repositories(user_id);
CREATE INDEX idx_daily_reports_user_id ON public.daily_reports(user_id);
CREATE INDEX idx_daily_reports_date ON public.daily_reports(report_date);
CREATE INDEX idx_work_trends_user_id ON public.work_trends(user_id);
CREATE INDEX idx_work_trends_date ON public.work_trends(date);
CREATE INDEX idx_blockers_user_id ON public.blockers(user_id);
CREATE INDEX idx_blockers_status ON public.blockers(status);

-- 创建更新时间触发器函数
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 为需要的表添加更新时间触发器
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_git_repositories_updated_at BEFORE UPDATE ON public.git_repositories
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_daily_reports_updated_at BEFORE UPDATE ON public.daily_reports
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_blockers_updated_at BEFORE UPDATE ON public.blockers
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_settings_updated_at BEFORE UPDATE ON public.user_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 创建用户同步触发器
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  INSERT INTO public.profiles (id, username, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    NEW.email,
    CASE WHEN user_count = 0 THEN 'admin'::public.user_role ELSE 'user'::public.user_role END
  );
  
  INSERT INTO public.user_settings (user_id)
  VALUES (NEW.id);
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();

-- 创建辅助函数检查管理员权限
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- 启用 RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.git_repositories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.work_trends ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blockers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;

-- Profiles 表策略
CREATE POLICY "管理员可以查看所有用户" ON public.profiles
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "用户可以查看自己的资料" ON public.profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "用户可以更新自己的资料" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

CREATE POLICY "管理员可以更新所有用户" ON public.profiles
  FOR UPDATE TO authenticated USING (is_admin(auth.uid()));

-- Git 仓库表策略
CREATE POLICY "用户可以查看自己的仓库" ON public.git_repositories
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "用户可以创建自己的仓库" ON public.git_repositories
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以更新自己的仓库" ON public.git_repositories
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "用户可以删除自己的仓库" ON public.git_repositories
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- 日报表策略
CREATE POLICY "用户可以查看自己的日报" ON public.daily_reports
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "管理员可以查看所有日报" ON public.daily_reports
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "用户可以创建自己的日报" ON public.daily_reports
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以更新自己的日报" ON public.daily_reports
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "用户可以删除自己的日报" ON public.daily_reports
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- 工作趋势表策略
CREATE POLICY "用户可以查看自己的趋势" ON public.work_trends
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "管理员可以查看所有趋势" ON public.work_trends
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "用户可以创建自己的趋势" ON public.work_trends
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以更新自己的趋势" ON public.work_trends
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- 阻塞表策略
CREATE POLICY "用户可以查看自己的阻塞" ON public.blockers
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "管理员可以查看所有阻塞" ON public.blockers
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "用户可以创建自己的阻塞" ON public.blockers
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以更新自己的阻塞" ON public.blockers
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "用户可以删除自己的阻塞" ON public.blockers
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- 用户设置表策略
CREATE POLICY "用户可以查看自己的设置" ON public.user_settings
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "用户可以更新自己的设置" ON public.user_settings
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- 创建公开视图供分享使用
CREATE VIEW public.public_profiles AS
  SELECT id, username, avatar_url, role FROM profiles;