-- 添加 work_items 字段到 daily_reports 表
ALTER TABLE daily_reports 
ADD COLUMN IF NOT EXISTS work_items JSONB DEFAULT '[]'::jsonb;